## Dev
* [expand the minting metadata for Teia by NoRulesJustFeels](https://docs.google.com/document/d/1R3rxuJfpCBoh52wDsYpEmY_iuH8sd6l17oh4nk7jlRE/edit)

## DAO-implementation

* [main DAO discussion in forum](https://discourse.hencommunity.quest/t/the-hic-et-nunc-dao-implementation-discussion/286/33)
* [Main Working Doc for DAO](https://docs.google.com/document/d/19e-UrTX5ME5ZUVpyc7ZunrTckJgei5UQsCeCHfB0nnk/edit#)
* [epresentative governance by esduhh](https://docs.google.com/document/d/1iM9F021jjatLSqzETqLsHuBF0wiGiu9WrbDIL9tyaSo/edit)
* ["decentralized guilds" by babycommando](https://docs.google.com/document/d/10Or12QOKJ-xdO_Lkz33-86aVHyuz5lmheLhMwXgpEI0/edit?usp=sharing)
* [Org structure proposal by malicious sheep](https://discourse.hencommunity.quest/t/organization-proposal/594)

![teiavote](https://user-images.githubusercontent.com/97635650/159079046-090aea53-14a3-4442-a33e-587f59abaa5a.png)
![Agora](https://user-images.githubusercontent.com/97635650/159079076-54f916e2-dfcf-4dc2-a1f8-e21d67eaac3f.png)


## PR-Communication

* [Info flow proposal by Merchant Coppola](https://docs.google.com/document/d/1juzmxCvFsc1-_ayicFmNmrTD12YpQEJ3FZdzdDBUxFw/edit#)

## Community And culture
* [Core Values general Input/thoughts](https://docs.google.com/document/d/1nz9PyymhDrThgIPoCYFPPRCGSLmm4igfvUwKyHhYz2s/edit#heading=h.8xjakf1xplar)
* [Core values/Code of Conduct working Doc](https://docs.google.com/document/d/13QvryUcCTk0KpROMsRUk3IYf3eK_jYkH63XDmzijj7Q/edit?usp=sharing)