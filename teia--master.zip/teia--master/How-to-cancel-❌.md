### **cancel**

1: _(verb)_ to take your NFT off the market

***

To take your OBJKT off the marketplace and no longer for purchase:

1. Make sure your wallet is synced.
2. Load the page for your OBJKT.
3. Click on "listings" and then "cancel". This will send the OBJKTs from the escrow wallet to your wallet. Check your wallet for confirmation.
4. Now that they are back in your wallet, you can "swap" them again or burn them.

If you want to delete your OBJKT, continue to [How to burn 🔥](https://github.com/teia-community/teia-docs/wiki/How-to-burn-🔥)
***

**Important:** _If you try to "swap" OBJKTs that are currently for sale, your wallet will throw a warning saying that you have `insufficient funds`. This is because you already sent your OBJKTs to the escrow wallet in the first swap. You need to "cancel" to get the OBJKTs back in your wallet, and then you can "swap" them again._