Conversations on twitter and discord get lost. Our community forum is for discussing community issues where the posts can be easily referenced and documented.

https://discourse.hencommunity.quest/