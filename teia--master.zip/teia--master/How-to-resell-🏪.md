How to sell an OBJKT you own.

***
This is also referred to as placing your OBJKT on the secondary market.

1. Make sure your wallet is synced.
2. Load your account page on Teia.
3. Click on "collection" and click on the OBJKT you want to resell.
4. Click on the "listings" tab to see all of the owners and sellers.
5. Click on "swap" and set a price for your OBJKT.
6. Click on the "swap" button and confirm the transaction in your wallet app.

_IMPORTANT: Once swapping something up for sale, it is held in the Teia escrow wallet while it is "on the market." Therefore, the OBJKT will disappear from your collections. Don't worry; it's still up for sale!_


***

### How can I track what I've sold?

You can use the tools on [hicdex.com](hicdex.com) to track transaction history

### How can I get notifications when I sell something?

You can use the [Telegram Notifier Bot](https://tzsnt.fr/) to get a notification everytime something sells.