Tutorials created by the hicetnunc community

(Since the platform changes so much we think you'll find the latest ones to be most relevant)

***
* [How to Mint an NFT - Complete guide for TOTAL BEGINNERS - Tezos on Hic Et Nunc](https://youtu.be/KJSsjapuG3o)
* [How I create NFTs on Hic Et Nunc 👾🌍♻️](https://youtu.be/VOa1Ky4rcKc) by Banjo Funk _8 April, 2021_
* [Quickstart Tutorial Videos](https://twitter.com/verticalcrypto/status/1374349022245359627) by VerticalCrypto _23 March, 2021_
> <a href="https://twitter.com/verticalcrypto/status/1374349022245359627?s=20"><img src="https://i.ibb.co/YcVtFjG/hicetnunc-starter-pt1-wallet.gif" alt="hicetnunc-starter-pt1-wallet" border="0"></a>

> This 3-Part video tutorial covers:
> 1. Wallet (setup a Tezos wallet and get your first TEZ)
> 2. Mint (mint your first NFT)
> 3. Swap (price & list your NFT)
* [Getting Started As An NFT Artist On Tezos Using Hicetnunc](https://xtz.news/latest-tezos-news/getting-started-as-an-nft-artist-on-tezos-using-hicetnunc) by XTZ News _16 March, 2021_