# Como descartar(burn) 🔥

### descartar
verbo
1: (verbo) retirar ou pôr de lado (uma ou mais cartas de baralho, jogo etc.) para determinado fim ou por não apresentar(em) serventia.

2: (verbo) deletar seu OBJKT


***


1. Certifique-se que sua carteira está sincronizada com o hen.
2. Pressione o botão [burn]descartar. Em sua carteira, o OBJKT deve subir como sendo transferido para a carteira de gravação.
3. Se o botão de [burn]descarte não estiver funcionando, você pode enviar o OBJKT para um endereço de carteira de descarte diretamente de sua carteira Tezos. O endereço é: ```tz1burnburnburnburnburnburnburjAYjjX```

_Importante: Você precisa [cancel]cancelar a curadoria deste OBJKT para que ele fique disponível em sua carteira quando você estiver pronto para [burn]descartá-lo._

**Dica: as transações no blockchain são irreversíveis, por isso você precisa enviá-lo para outra carteira. O endereço de gravação é um endereço do qual ninguém possui uma chave.**