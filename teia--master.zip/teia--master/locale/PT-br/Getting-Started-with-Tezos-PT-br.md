# Introdução ao Tezos
Primeiro você precisará do Tezos e de uma carteira do Tezos.

## O que é Tezos?
Tezos (XTZ) é uma criptomoeda à prova de apostas (LPoS). Você pode ler mais sobre isso [aqui](https://en.wikipedia.org/wiki/Tezos)

## Que carteiras você recomenda?
A maioria dos nossos usuários usa a [carteira Kukai](https://wallet.kukai.app/) ou a [carteira Temple](https://templewallet.com/). Vimos problemas com o Airgap, então não o recomendamos.

## Onde comprar tezos
Cunhar no hicetnunc custa apenas ~ 0,08 tezos. Você pode comprar alguns em um site de câmbio como Binance ou Kraken, no entanto, recomendamos consultar alguém que seja de qualquer país em que você esteja, porque os serviços de câmbio são fornecidos dependendo do país.

Já tem tezos ?

Continue em [Como cunhar](https://github.com/teia-community/teia-docs/wiki/How-to-mint-🌿-pt-BR) 🌿 para criar seu primeiro OBJKT!