# hDAO

FATOS:
* Tezos FA2 Token
* 651k fornecimento total
* Token do hicetnunc.xyz (~ 20k xtz de volume 24h)
* Valor de mercado de aproximadamente $ 16 milhões
* Maior holder <3% do fornecimento total *

Utilidades
* BJKT (nft) upvoting
* Governança do Hicetnunc
* Dividendos potenciais

_a partir de 29 de abril_

**implementação em andamento**