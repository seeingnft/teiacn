Bem-vindo ao teia.art wiki!

A Comunidade Teia está trabalhando em um garfo comunitário de código aberto da plataforma Tezos NFT Hic et Nunc / H=N que visa continuar o espírito de H=N de forma descentralizada.